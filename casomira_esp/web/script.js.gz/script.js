//var barvy = Object(); 

var proudari = {
	muzi:{
		pProud:[],
		lProud:[]
	},
	zeny:{
		pProud:[],
		lProud:[]
	}
}
var data;
function getMousePos(canvas, evt) 
{
	var rect = canvas.getBoundingClientRect();
    return {
        x: evt.clientX - rect.left, y: evt.clientY - rect.top
    };
}

function pixelOnMouseOver(canvas,callback)
{
	ctx = canvas.getContext("2d");
	var w = canvas.width, h=canvas.height;
	data= ctx.getImageData(0,0,w,h).data;
	canvas.addEventListener('mousemove',function(e)
	{
		if (e.offsetX === void 0) {
    Object.defineProperties(MouseEvent.prototype, {
      'offsetX': {
        get: function() {
          return this.layerX - this.target.offsetLeft;
        }
      }
      , 'offsetY': {
        get: function() {
          return this.layerY - this.target.offsetTop;
        }
      }
    });
  }
		var idx = (e.offsetY*w + e.offsetX)*4;
		var parts = Array.prototype.slice.call(data,idx,idx+4);
		mousePos = getMousePos(canvas, e);
		//document.getElementById("bbb").innerHTML=Math.floor(mousePos.x/100)+1;
		callback.apply(ctx,parts);
	},false);
}


function mouse()
{
	return Math.floor(mousePos.x/100);
}


function addProudari(pohlavi,soutez,pProud,lProud)
{
	proudari[pohlavi].pProud[soutez-1]=pProud;
	proudari[pohlavi].lProud[soutez-1]=lProud;
}

function printProudari(canvas,zvirazni,pohlavi)
{
	var c = canvas.getContext("2d");
	var vyska = canvas.height;
	c.clearRect(0,0,canvas.width,vyska);
	for(var j=0;j<proudari[pohlavi].pProud.length;j++)
	{
		c.beginPath();
		if(j==0)
			c.moveTo(0,vyska);
		else
			c.moveTo(100*j,vyska-(vyska/4600*(proudari[pohlavi].pProud[j-1]-1400)));
		c.strokeStyle="rgb(255,0,0)";
		c.lineTo(100*(j+1),vyska-(vyska/4600*(proudari[pohlavi].pProud[j]-1400)));
		if("pravy"==zvirazni)
			c.lineWidth = 10;
		else
			c.lineWidth = 2;
		c.lineCap   = 'round';	
		c.stroke();
	}
	for(var j=0;j<proudari[pohlavi].lProud.length;j++)
	{
		c.beginPath();
		if(j==0)
			c.moveTo(0,vyska);
		else
			c.moveTo(100*j,vyska-(vyska/4600*(proudari[pohlavi].lProud[j-1]-1400)));
		c.strokeStyle="rgb(0,0,255)";
		c.lineTo(100*(j+1),vyska-(vyska/4600*(proudari[pohlavi].lProud[j]-1400)));
		if("levy"==zvirazni)
			c.lineWidth = 10;
		else
			c.lineWidth = 2;
		c.lineCap   = 'round';	
		c.stroke();
	}
}